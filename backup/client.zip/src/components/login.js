

const Login = () => {
    return(
        <>
            <div className="header">
                
            </div>
        </>
    )
}
export default Login;