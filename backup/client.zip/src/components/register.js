

const Register = () => {
    return(
        <>
            <div className="header">
                <label style={{fontSize:"35px"}}>TODO APP</label>
                <p>userName</p>
            </div>
        </>
    )
}
export default Register;